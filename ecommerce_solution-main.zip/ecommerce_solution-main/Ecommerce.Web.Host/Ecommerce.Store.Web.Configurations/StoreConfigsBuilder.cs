﻿using Ecommerce.Store.Dto.StoreConfigurations;
using System.Reflection;
using System.Text.Json;

namespace Store.Web.Configurations
{
    public interface IStoreConfigsBuilder
    {
        public StoreConfigurationsDto GetStoreInfo(string storeUlr);
    }
    //public static class StoreConfigsBuilderExtension
    //{
    //    public static IStoreConfigsBuilder StoreConfigs { get { return new StoreConfigsBuilder(); } }
    //}
    public class StoreConfigsBuilder : IStoreConfigsBuilder
    {
        private string GetStoreConfigFromFile()
        {
            try
            {
                var assembly = Assembly.GetExecutingAssembly();
                var resourceName = "Store.Web.Configurations.store_configs.json"; // namespace + filename

                using var stream = assembly.GetManifestResourceStream(resourceName);
                if (stream == null)
                    throw new FileNotFoundException($"Embedded resource '{resourceName}' not found.");

                using var reader = new StreamReader(stream);
                var json = reader.ReadToEnd();
                return json;
            }
            catch (Exception)
            {
                // Log exception or handle it as needed
                throw;
            }

        }
        public StoreConfigurationsDto GetStoreInfo(string storeUlr)
        {
            try
            {
                string content = GetStoreConfigFromFile();
                var configs = JsonSerializer.Deserialize<List<StoreConfigurationsDto>>(content);
                var storeInfo = configs.FirstOrDefault(c => c.StoreInfo.StoreUrl.Equals(storeUlr, StringComparison.OrdinalIgnoreCase));
                return storeInfo;
            }
            catch (Exception)
            {
                throw;
            }

        }
    }
}
