﻿using Ecommerce.Store.Dto.StoreConfigurations;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using Store.Web.Configurations;

namespace Ecommerce.Store.Web.Startup.Controllers
{
    public class BaseController : Controller
    {
        public StoreConfigurationsDto StoreConfigurationsDto { get; set; }


        public override void OnActionExecuting(ActionExecutingContext context)
        {
            SetStoreConfigs();
            SetStoreLayout();

            base.OnActionExecuting(context);
        }

        private void SetStoreConfigs()
        {
            IStoreConfigsBuilder storeConfigsBuilder = HttpContext.RequestServices.GetService(typeof(IStoreConfigsBuilder)) as IStoreConfigsBuilder;

            string applicationUrl = $"{HttpContext.Request.Scheme}://{HttpContext.Request.Host.Host}:{HttpContext.Request.Host.Port}";

            this.StoreConfigurationsDto = storeConfigsBuilder.GetStoreInfo(applicationUrl);
        }
        private void SetStoreLayout()
        {
            if (this.StoreConfigurationsDto is not null)
            {
                ViewBag.Layout = this.StoreConfigurationsDto.StoreLayoutConfigs.StoreLayout;
            }
            else
            {
                ViewBag.Layout = "_Layout";
            }
        }
    }
}
