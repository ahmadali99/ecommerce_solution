﻿using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;

namespace Ecommerce.Store.Web.Startup.ViewComponents
{
    public class DynamicLayoutHandlerViewComponent : ViewComponent
    {
        public async Task<IViewComponentResult> InvokeAsync(string theme)
        {
            string viewName = theme.Equals("One")
                ? "_WebStoreLayout1"
                : "_WebStoreLayout2";

            return View(viewName);
        }
    }
}
