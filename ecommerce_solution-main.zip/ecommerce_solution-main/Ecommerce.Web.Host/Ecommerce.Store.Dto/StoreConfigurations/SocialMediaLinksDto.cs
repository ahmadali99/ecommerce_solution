﻿namespace Ecommerce.Store.Dto.StoreConfigurations
{
    public class SocialMediaLinksDto
    {
        public string Facebook { get; set; }
        public string Twitter { get; set; }
        public string Instagram { get; set; }
    }
}
