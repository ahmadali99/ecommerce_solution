﻿namespace Ecommerce.Store.Dto.StoreConfigurations
{
    public class StoreConfigurationsDto
    {
        public StoreInfoDto StoreInfo { get; set; }
        public StoreLayoutConfigs StoreLayoutConfigs { get; set; }
    }
    public class StoreInfoDto
    {
        public int Id { get; set; }
        public string StoreName { get; set; }
        public string StoreUrl { get; set; }
        public string StoreOwner { get; set; }
        public string Description { get; set; }
        public string Currency { get; set; }
        public string StoreLogoUrl { get; set; }
        public string ContactEmail { get; set; }
        public string ContactPhone { get; set; }
        public string Address { get; set; }
        public List<string> SupportedLanguages { get; set; }
        public string TimeZone { get; set; }
        public List<string> PaymentMethods { get; set; }
        public List<string> ShippingOptions { get; set; }
        public double TaxRate { get; set; }
        public string ReturnPolicy { get; set; }
        public string PrivacyPolicy { get; set; }
        public string TermsOfService { get; set; }
        public string AnalyticsTrackingId { get; set; }
        public bool MaintenanceMode { get; set; }
        public List<int> FeaturedProducts { get; set; }
        public SocialMediaLinksDto SocialMediaLinks { get; set; }
    }
}
