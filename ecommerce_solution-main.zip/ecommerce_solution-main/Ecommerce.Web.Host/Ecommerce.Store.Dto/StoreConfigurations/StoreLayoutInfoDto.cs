﻿namespace Ecommerce.Store.Dto.StoreConfigurations
{
    public class StoreLayoutConfigs
    {
        public string Theme { get; set; }
        public string StoreLayout { get; set; }
        public string LayoutFileName { get; set; }
    }
}
